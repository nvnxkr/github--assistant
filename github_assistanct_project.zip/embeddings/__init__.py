"""embeddings package"""
